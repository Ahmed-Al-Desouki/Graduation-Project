// ignore_for_file: prefer_single_quotes
class Assets {
  Assets._();
  
  /// Assets for imagesAge
  /// assets/images/age.svg
  static const String imagesAge = "assets/images/age.svg";

  /// Assets for imagesAward
  /// assets/images/award.svg
  static const String imagesAward = "assets/images/award.svg";

  /// Assets for imagesBell
  /// assets/images/bell.svg
  static const String imagesBell = "assets/images/bell.svg";

  /// Assets for imagesBirth
  /// assets/images/birth.svg
  static const String imagesBirth = "assets/images/birth.svg";

  /// Assets for imagesBlood
  /// assets/images/blood.svg
  static const String imagesBlood = "assets/images/blood.svg";

  /// Assets for imagesCalendarDays
  /// assets/images/calendar_days.svg
  static const String imagesCalendarDays = "assets/images/calendar_days.svg";

  /// Assets for imagesCamera
  /// assets/images/camera.svg
  static const String imagesCamera = "assets/images/camera.svg";

  /// Assets for imagesCertificate
  /// assets/images/certificate.svg
  static const String imagesCertificate = "assets/images/certificate.svg";

  /// Assets for imagesChartLine
  /// assets/images/chart_line.svg
  static const String imagesChartLine = "assets/images/chart_line.svg";

  /// Assets for imagesChronicDiseases
  /// assets/images/chronic_diseases.svg
  static const String imagesChronicDiseases = "assets/images/chronic_diseases.svg";

  /// Assets for imagesClock
  /// assets/images/clock.svg
  static const String imagesClock = "assets/images/clock.svg";

  /// Assets for imagesDoctor
  /// assets/images/doctor.png
  static const String imagesDoctor = "assets/images/doctor.png";

  /// Assets for imagesEducationVerification
  /// assets/images/education-verification.svg
  static const String imagesEducationVerification = "assets/images/education-verification.svg";

  /// Assets for imagesEmergency
  /// assets/images/emergency.svg
  static const String imagesEmergency = "assets/images/emergency.svg";

  /// Assets for imagesHIPAACompliant
  /// assets/images/HIPAA_compliant.svg
  static const String imagesHIPAACompliant = "assets/images/HIPAA_compliant.svg";

  /// Assets for imagesHeartRate
  /// assets/images/heart_rate.svg
  static const String imagesHeartRate = "assets/images/heart_rate.svg";

  /// Assets for imagesHeight
  /// assets/images/height.svg
  static const String imagesHeight = "assets/images/height.svg";

  /// Assets for imagesHelp
  /// assets/images/help.svg
  static const String imagesHelp = "assets/images/help.svg";

  /// Assets for imagesId
  /// assets/images/id.svg
  static const String imagesId = "assets/images/id.svg";

  /// Assets for imagesIdentification
  /// assets/images/identification.svg
  static const String imagesIdentification = "assets/images/identification.svg";

  /// Assets for imagesInfo
  /// assets/images/info.svg
  static const String imagesInfo = "assets/images/info.svg";

  /// Assets for imagesLock
  /// assets/images/lock.svg
  static const String imagesLock = "assets/images/lock.svg";

  /// Assets for imagesLogin
  /// assets/images/login.png
  static const String imagesLogin = "assets/images/login.png";

  /// Assets for imagesLogout
  /// assets/images/logout.svg
  static const String imagesLogout = "assets/images/logout.svg";

  /// Assets for imagesMeds
  /// assets/images/meds.svg
  static const String imagesMeds = "assets/images/meds.svg";

  /// Assets for imagesMobile
  /// assets/images/mobile.svg
  static const String imagesMobile = "assets/images/mobile.svg";

  /// Assets for imagesPatient
  /// assets/images/patient.png
  static const String imagesPatient = "assets/images/patient.png";

  /// Assets for imagesPatients
  /// assets/images/patients.svg
  static const String imagesPatients = "assets/images/patients.svg";

  /// Assets for imagesPedningAcceptDoctor
  /// assets/images/pedning_accept_doctor.png
  static const String imagesPedningAcceptDoctor = "assets/images/pedning_accept_doctor.png";

  /// Assets for imagesPreferences
  /// assets/images/preferences.svg
  static const String imagesPreferences = "assets/images/preferences.svg";

  /// Assets for imagesPrivcy
  /// assets/images/privcy.svg
  static const String imagesPrivcy = "assets/images/privcy.svg";

  /// Assets for imagesProfilePlus
  /// assets/images/profile_plus.svg
  static const String imagesProfilePlus = "assets/images/profile_plus.svg";

  /// Assets for imagesRegisterDoctor
  /// assets/images/register_doctor.png
  static const String imagesRegisterDoctor = "assets/images/register_doctor.png";

  /// Assets for imagesRegisterPatient
  /// assets/images/register_patient.png
  static const String imagesRegisterPatient = "assets/images/register_patient.png";

  /// Assets for imagesSchduleBooking
  /// assets/images/schdule_booking.svg
  static const String imagesSchduleBooking = "assets/images/schdule_booking.svg";

  /// Assets for imagesSecure
  /// assets/images/secure.svg
  static const String imagesSecure = "assets/images/secure.svg";

  /// Assets for imagesStethoscope
  /// assets/images/stethoscope.svg
  static const String imagesStethoscope = "assets/images/stethoscope.svg";

  /// Assets for imagesStorage
  /// assets/images/storage.svg
  static const String imagesStorage = "assets/images/storage.svg";

  /// Assets for imagesUserDoctor
  /// assets/images/user_doctor.svg
  static const String imagesUserDoctor = "assets/images/user_doctor.svg";

  /// Assets for imagesUserRegular
  /// assets/images/user_regular.svg
  static const String imagesUserRegular = "assets/images/user_regular.svg";

  /// Assets for imagesVideo
  /// assets/images/video.svg
  static const String imagesVideo = "assets/images/video.svg";

  /// Assets for imagesWeight
  /// assets/images/weight.svg
  static const String imagesWeight = "assets/images/weight.svg";
}

